#pragma once
#ifndef _DB_IF_
#define _DB_IF_
#ifndef RC_INVOKED

#include <exception>

#include <string>

class DB_Exception : public std::exception {
public:
	DB_Exception();
	~DB_Exception();
};

class DB_Handle {
public:
	virtual ~DB_Handle();
	DB_Handle();
private:
	// DISABLE COPY & ASSIGN, �.�. ��������� �������� 
	// ��������� ��� ����� ���������� ���� ��� ����
	DB_Handle(const DB_Handle&);
	void operator=(const DB_Handle&);
public:
	virtual void connect(std::string const& file, std::string const& user, std::string const& pass);
	virtual void disconnect();
	virtual void* make_dataset();
	//virtual void* sql_statement();
//	operator()
private:
	void*			db_handle_;
	std::string		file_name_;
	std::string		user_name_;
};

class DB_Price {
	/*
	price_prov_id     integer not null,
	price_prod_art    text not null,
	price_end_user    real not null,
	price_catalo_code    text default null,
	*/
public:
	std::string get_cat_code(std::string const& prod_art, std::string const& prov_id);
	std::string get_end_user(std::string const& prod_art, std::string const& prov_id);
	std::string get_prov_ids(std::string const& prod_art);

private:
	void select_from_db_table(std::string const& prod_art);
	void*	        sql_stmt_handle_;
	std::string		price_end_user_;
	std::string		price_cat_code_;
};







#include "http_args_parser.h"





#include <map>
#include <string>

class View : protected HttpArgsParser<
		//HttpPostArgsParser_ErrorPolicy_ThrowExcept<std::runtime_error>,
		HttpPostArgsParser_ErrorPolicy_ReturnErrMsg,
		HttpPostArgsParser_EcodingPolicy_Multipart
> {
public:
	View(const char* data_ptr, const char* data_end, const char* delimit_psz);
	virtual ~View() {}
	void view_plus(std::string& html_output) {
		view(html_output, http_args_);
	}
	void view(std::string& html_output, std::map<std::string, std::string>& http_args);

	// todo: ���������� �� "http_args_"
	//std::map<std::string, std::string>	http_args_;
protected:
	std::map<std::string const, std::string* const>	args_tree_;
	//std::string	cmd_str_;
	std::string	calc_str_;
	std::string	item_str_;
	//std::string	ordr_str_;
	std::string	prod_str_;
	std::string	slot_str_;
	std::string	user_str_;
	std::string	view_str_;

	void insert_item_to_calc(std::string& html_output, std::string const& item_str);
	void select_calc_for_id(std::string& html_output, std::string const& calc_str);
	void select_file_for_prod(std::string& html_output, std::string const& prod_str);
	void select_prods_for_slot(std::string& html_output, std::string const& slot_str);
	void select_slots_for_prod(std::string& html_output, std::string const& prod_str);
	virtual char const* http_args_parser_insert_pair(char const* name_ptr, char const* name_end, char const* value_ptr, char const* value_end) {
		// todo: ��������� ��� ���������� calc_str_ ... user_str_
		std::string const name_str(name_ptr, name_end);
		std::string const value_str(value_ptr, value_end);
		//http_args_.insert(std::make_pair(name_str, value_str));

		std::map<std::string const, std::string* const>::iterator args_iter(args_tree_.find(name_str));
		if( args_tree_.end()!=args_iter )	args_iter->second->assign(value_str);
		return 0;
	}
};


#endif /* RC_INVOKED */
#endif /* _DB_IF_ */