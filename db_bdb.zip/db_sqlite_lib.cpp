typedef int (*sqlite3_open_t)(
		char const* filename,   /* Database filename (UTF-8) */
		sqlite3** ppDb          /* OUT: SQLite db handle */
	);
typedef int (*sqlite3_prepare_v2_t)(
		sqlite3 *db,            /* Database handle */
		const char *zSql,       /* SQL statement, UTF-8 encoded */
		int nByte,              /* Maximum length of zSql in bytes. */
		sqlite3_stmt **ppStmt,  /* OUT: Statement handle */
		const char **pzTail     /* OUT: Pointer to unused portion of zSql */
	);
typedef int (*sqlite3_finalize_t)(sqlite3_stmt *pStmt);
typedef int (*sqlite3_step_t)(sqlite3_stmt*);
typedef int (*sqlite3_column_bytes_t)(sqlite3_stmt*, int iCol);
typedef int (*sqlite3_column_type_t)(sqlite3_stmt*, int iCol);
typedef	double (*sqlite3_column_double_t)(sqlite3_stmt*, int iCol);
typedef const unsigned char * (*sqlite3_column_text_t)(sqlite3_stmt*, int iCol);

static HMODULE sqlite3_hlib = 0;
sqlite3_open_t sqlite3_open = 0;
sqlite3_prepare_v2_t sqlite3_prepare_v2 = 0;
sqlite3_finalize_t sqlite3_finalize = 0;
sqlite3_step_t sqlite3_step = 0;
sqlite3_column_bytes_t sqlite3_column_bytes = 0;
sqlite3_column_type_t sqlite3_column_type = 0;
sqlite3_column_double_t sqlite3_column_double = 0;
sqlite3_column_text_t sqlite3_column_text = 0;

static void sqlite_init() {
	if( 0==sqlite3_hlib ) {
		::sqlite3_hlib = ::LoadLibrary("sqlite3.dll");
		::sqlite3_open = (sqlite3_open_t)::GetProcAddress(sqlite3_hlib, "sqlite3_open");
		::sqlite3_prepare_v2 = (sqlite3_prepare_v2_t)::GetProcAddress(sqlite3_hlib, "sqlite3_prepare_v2");
		::sqlite3_finalize = (sqlite3_finalize_t)::GetProcAddress(sqlite3_hlib,"sqlite3_finalize");
		::sqlite3_step = (sqlite3_step_t)::GetProcAddress(sqlite3_hlib, "sqlite3_step");
		::sqlite3_column_bytes = (sqlite3_column_bytes_t)::GetProcAddress(sqlite3_hlib, "sqlite3_column_bytes");
		::sqlite3_column_type = (sqlite3_column_type_t)::GetProcAddress(sqlite3_hlib, "sqlite3_column_type");
		::sqlite3_column_double = (sqlite3_column_double_t)::GetProcAddress(sqlite3_hlib, "sqlite3_column_double");
		::sqlite3_column_text = (sqlite3_column_text_t)::GetProcAddress(sqlite3_hlib, "sqlite3_column_text");
	}
}